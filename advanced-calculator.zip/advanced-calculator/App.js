import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
  Keyboard,
  Animated,
  Easing
} from 'react-native';

export default function AdvancedCalculator() {
  const [value1, setValue1] = useState('');
  const [value2, setValue2] = useState('');
  const [operation, setOperation] = useState(null);
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [scaleAnim] = useState(new Animated.Value(1));

  const animateButton = () => {
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.95,
        duration: 100,
        easing: Easing.ease,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        easing: Easing.ease,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const selectOperation = (op) => {
    setOperation(op);
    animateButton();
    Keyboard.dismiss();
  };

  const calculate = () => {
    if (!value1 || !value2) {
      Alert.alert('⚠️ Attention', 'Veuillez remplir les deux champs');
      return;
    }

    if (!operation) {
      Alert.alert('⚠️ Attention', 'Veuillez sélectionner une opération');
      return;
    }

    const num1 = parseFloat(value1.replace(',', '.'));
    const num2 = parseFloat(value2.replace(',', '.'));

    if (isNaN(num1) || isNaN(num2)) {
      Alert.alert('❌ Erreur', 'Veuillez entrer des nombres valides');
      return;
    }

    let calculatedResult;
    let operationSymbol = operation;

    switch (operation) {
      case '+':
        calculatedResult = num1 + num2;
        operationSymbol = '+';
        break;
      case '-':
        calculatedResult = num1 - num2;
        operationSymbol = '−';
        break;
      case '*':
        calculatedResult = num1 * num2;
        operationSymbol = '×';
        break;
      case '/':
        if (num2 === 0) {
          Alert.alert('❌ Erreur', 'Division par zéro impossible');
          return;
        }
        calculatedResult = num1 / num2;
        operationSymbol = '÷';
        break;
      default:
        calculatedResult = null;
    }

    const calculation = {
      expression: `${num1} ${operationSymbol} ${num2}`,
      result: calculatedResult,
      timestamp: new Date().toLocaleTimeString()
    };

    setResult(calculatedResult);
    setHistory(prev => [calculation, ...prev.slice(0, 4)]); // Garder les 5 derniers
    animateButton();
    Keyboard.dismiss();
  };

  const clearAll = () => {
    setValue1('');
    setValue2('');
    setOperation(null);
    setResult(null);
    animateButton();
    Keyboard.dismiss();
  };

  const clearHistory = () => {
    setHistory([]);
    animateButton();
  };

  const OperationButton = ({ op, symbol, onPress, isSelected }) => (
    <TouchableOpacity
      style={[
        styles.operationButton,
        isSelected && styles.selectedOperation,
        op === '/' && styles.divisionButton
      ]}
      onPress={() => onPress(op)}
    >
      <Text style={[
        styles.operationSymbol,
        isSelected && styles.selectedOperationSymbol
      ]}>
        {symbol}
      </Text>
    </TouchableOpacity>
  );

  return (
    <ScrollView 
      contentContainerStyle={styles.container}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>🧮 Smart Calculator</Text>
        <Text style={styles.subtitle}>Calculateur Avancé</Text>
      </View>

      {/* Input Section */}
      <View style={styles.inputSection}>
        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Premier nombre</Text>
          <TextInput
            style={styles.input}
            placeholder="Entrez un nombre..."
            placeholderTextColor="#a0a0a0"
            keyboardType="numeric"
            value={value1}
            onChangeText={setValue1}
            selectionColor="#6366f1"
          />
        </View>

        <View style={styles.inputContainer}>
          <Text style={styles.inputLabel}>Deuxième nombre</Text>
          <TextInput
            style={styles.input}
            placeholder="Entrez un nombre..."
            placeholderTextColor="#a0a0a0"
            keyboardType="numeric"
            value={value2}
            onChangeText={setValue2}
            selectionColor="#6366f1"
          />
        </View>
      </View>

      {/* Operations Grid */}
      <View style={styles.operationsSection}>
        <Text style={styles.sectionTitle}>Opérations</Text>
        <View style={styles.operationsGrid}>
          <OperationButton op="+" symbol="+" onPress={selectOperation} isSelected={operation === '+'} />
          <OperationButton op="-" symbol="−" onPress={selectOperation} isSelected={operation === '-'} />
          <OperationButton op="*" symbol="×" onPress={selectOperation} isSelected={operation === '*'} />
          <OperationButton op="/" symbol="÷" onPress={selectOperation} isSelected={operation === '/'} />
        </View>
        
        {operation && (
          <Animated.View style={[styles.selectedOperationDisplay, { transform: [{ scale: scaleAnim }] }]}>
            <Text style={styles.selectedOperationText}>
              Opération sélectionnée: { 
                operation === '+' ? 'Addition' :
                operation === '-' ? 'Soustraction' :
                operation === '*' ? 'Multiplication' : 'Division'
              }
            </Text>
          </Animated.View>
        )}
      </View>

      {/* Action Buttons */}
      <View style={styles.actionsSection}>
        <TouchableOpacity
          style={[styles.actionButton, styles.calculateButton]}
          onPress={calculate}
        >
          <Text style={styles.actionButtonText}>🚀 Calculer</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.actionButton, styles.clearButton]}
          onPress={clearAll}
        >
          <Text style={styles.actionButtonText}>🗑️ Tout Effacer</Text>
        </TouchableOpacity>
      </View>

      {/* Result Section */}
      {result !== null && (
        <Animated.View 
          style={[styles.resultContainer, { transform: [{ scale: scaleAnim }] }]}
        >
          <Text style={styles.resultLabel}>Résultat</Text>
          <Text style={styles.resultText}>
            {value1} { 
              operation === '+' ? '+' :
              operation === '-' ? '−' :
              operation === '*' ? '×' : '÷'
            } {value2} = 
          </Text>
          <Text style={styles.resultValue}>{result}</Text>
        </Animated.View>
      )}

      {/* History Section */}
      {history.length > 0 && (
        <View style={styles.historySection}>
          <View style={styles.historyHeader}>
            <Text style={styles.historyTitle}>📊 Historique</Text>
            <TouchableOpacity onPress={clearHistory}>
              <Text style={styles.clearHistoryText}>Effacer</Text>
            </TouchableOpacity>
          </View>
          {history.map((item, index) => (
            <View key={index} style={styles.historyItem}>
              <Text style={styles.historyExpression}>{item.expression}</Text>
              <Text style={styles.historyResult}>= {item.result}</Text>
              <Text style={styles.historyTime}>{item.timestamp}</Text>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#0f172a',
    padding: 20,
    paddingTop: 60,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#f8fafc',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 18,
    color: '#94a3b8',
    fontWeight: '500',
  },
  inputSection: {
    marginBottom: 30,
  },
  inputContainer: {
    marginBottom: 20,
  },
  inputLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#e2e8f0',
    marginBottom: 8,
    marginLeft: 5,
  },
  input: {
    backgroundColor: '#1e293b',
    borderWidth: 2,
    borderColor: '#334155',
    borderRadius: 16,
    paddingHorizontal: 20,
    paddingVertical: 16,
    fontSize: 18,
    color: '#f8fafc',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  operationsSection: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#e2e8f0',
    marginBottom: 20,
    textAlign: 'center',
  },
  operationsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 12,
    marginBottom: 20,
  },
  operationButton: {
    flex: 1,
    backgroundColor: '#1e293b',
    height: 70,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#334155',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  selectedOperation: {
    backgroundColor: '#6366f1',
    borderColor: '#818cf8',
    transform: [{ scale: 1.05 }],
  },
  divisionButton: {
    // Style spécial pour division
  },
  operationSymbol: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#f8fafc',
  },
  selectedOperationSymbol: {
    color: '#ffffff',
  },
  selectedOperationDisplay: {
    backgroundColor: '#6366f1',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
  },
  selectedOperationText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: '600',
  },
  actionsSection: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 30,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 18,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
  },
  calculateButton: {
    backgroundColor: '#10b981',
  },
  clearButton: {
    backgroundColor: '#ef4444',
  },
  actionButtonText: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: 'bold',
  },
  resultContainer: {
    backgroundColor: '#1e293b',
    padding: 24,
    borderRadius: 20,
    borderLeftWidth: 6,
    borderLeftColor: '#10b981',
    marginBottom: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 12,
  },
  resultLabel: {
    fontSize: 16,
    color: '#94a3b8',
    marginBottom: 8,
    fontWeight: '600',
  },
  resultText: {
    fontSize: 18,
    color: '#e2e8f0',
    marginBottom: 12,
    fontWeight: '500',
  },
  resultValue: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#10b981',
    textAlign: 'center',
  },
  historySection: {
    backgroundColor: '#1e293b',
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  historyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  historyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#f8fafc',
  },
  clearHistoryText: {
    color: '#ef4444',
    fontSize: 14,
    fontWeight: '600',
  },
  historyItem: {
    backgroundColor: '#334155',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  historyExpression: {
    fontSize: 16,
    color: '#e2e8f0',
    fontWeight: '500',
    flex: 2,
  },
  historyResult: {
    fontSize: 16,
    color: '#10b981',
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  historyTime: {
    fontSize: 12,
    color: '#94a3b8',
    flex: 1,
    textAlign: 'right',
  },
});